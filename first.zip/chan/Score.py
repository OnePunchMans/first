'''
万类之始，用于评价该策略的胜率，所有的策略继承此类
'''
import numpy as np
import pandas as pd
import pymongo
from pymongo import MongoClient


class Score(object):

    def __init__(self, perd=200, dock=None):
        self.dock = dock
        self.perd = perd
        self.db = MongoClient().get_database('day')

    def __cal__(self,one,two,three):#row为dict
        if (float(row['high']) - float(last_row['close'])) /float(last_row['close']) > 9 :
            return



    # 混淆矩阵计算
    # period输入list[数字]，表示天数
    # dock 空表示全部dock的，有代码算单个股票的
    def probability(self):

        # 取得上证指数的记录，方便关联
        sh = self.db.get_collection('1.000001').find(projection={'dat', 'Chg%'}).sort('dat', -1).limit(self.perd)
        sh = {i['dat']: i['Chg%'] for i in sh}
        # sh = dict(zip(sh['dat'], sh['close'])) 两种变成dict的方式
        sc = np.zeros((5,8),dtype = int)
        # 符合+1，涨+1，,高点>1 +1 ,后面桑是在大盘涨的情况下发生的
        for dock in (self.db.list_collection_names() if self.dock == None else [self.dock]):
            last_row = None  # 新股票开始，初始化为空
            for index, row in pd.DataFrame(self.db.get_collection(dock).find().sort('dat', -1).limit(self.perd)).sort_values(
                    by='dat').iterrows():
                row = row.to_dict()
                if (last_row):
                    sc['all'] += 1  # 昨日符合条件，今日存在股票数据，计数器加1
                    if float(row['Chg%']) > 0:
                        sc['1chg'] += 1
                    if float(row['high']) > float(last_row['close']):
                        sc['1high'] += 1
                    try:
                        if sh[row['dat']] != None and float(sh[row['dat']]) >= 0:
                            sc['A'] += 1
                        if sh[row['dat']] != None and float(sh[row['dat']]) >= 0 and float(row['Chg%']) > 0:
                            sc['1chgA'] += 1
                        if sh[row['dat']] != None and float(sh[row['dat']]) >= 0 and float(last_row['close'])> 2:
                            sc['1highA'] += 1
                    except:
                        pass

                one = row if self.isAgree(row) else None
        '''
        :return: (a,b)
        a是盲猜胜率
        b是大盘上涨的情况的胜率
        '''
        return {'detail': sc, '1win': round(sc['1chg'] / sc['all'], 4), '1high': round(sc['1high'] / sc['all'], 4),
                '1winA': round(sc['1chgA'] / sc['A'], 4), '1highA': round(sc['1highA'] / sc['A'], 4)}


        # 是否可以打分，空方法， 需要子类实现
        def isAgree(self, row):
            return False

        def getBuy():
            pass

    if __name__ == '__main__':
        pass
