import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# ====热力图
from matplotlib.ticker import FormatStrFormatter
rmf6 = pd.read_csv(r'D:\RMF6.csv', names=['MERCH_ID', 'R', 'M', 'F', 'FLAG', ])
rmf8 = pd.read_csv(r'D:\RMF8.csv', names=['MERCH_ID', 'R', 'M', 'F', 'FLAG', ])
df  =  pd.read_csv(r'D:\temp_wjc.csv', names=['MERCH_ID', 'ID_CARD', 'SEX', 'AGE', 'SHUI',
                                                                'DIGIT', 'PHONE', 'SAN', 'CREDIT_CARD', 'SFZ_HQ',
                                                                'SFZ_CX', 'SFZ_LC', 'SFZ_BX',
                                                                'SFZ_JJ', 'SFZ_GZ', 'ASSET_OTHER_BANKS',
                                                                'CX', 'HQ', 'D20', 'D21', 'D23', 'D24',
                                                                'D25', 'D26', 'D49', 'D50', 'D52', 'D53',
                                                                'D54', 'D66', 'D92', 'D11', 'D41', 'D2B',
                                                                'D2C', 'D2E', 'D2G', 'D2H', 'D2J', 'D42',
                                                                'D43', 'D2A', 'BX', 'CAI', 'SHOU', 'LC', 'HJ', 'HX',
                                                                'HB', 'HY', 'HYUAN', 'RRS', 'YYS', 'XXXR', 'JJ',
                                                                'GZ', 'BXJE', 'BXBS', 'LCJE', 'LCBS', 'JJJE',
                                                                'JJBS', 'LX',
                                                                ]).fillna('0')  # 空值填充
data6 = pd.concat([df,rmf6 ],keys='merch_id')
print(data6.head(10))
exit(0)
data = df.loc[:,'CX':'D2A']
#data.drop_duplicates() #去除重复行
# 计算两两属性之间的皮尔森相关系数
corrmat = data.corr()
f, ax = plt.subplots(figsize=(20, 20))

# 返回按“列”降序排列的前n行
#cols = corrmat.nlargest(26, data.columns[0]).index

# 返回皮尔逊积矩相关系数
#cm = np.corrcoef(data[cols].values.T)
sns.set(font_scale=1.25)
hm = sns.heatmap(corrmat,
                 cbar=True,
                 annot=True,
                 square=True,
                 fmt=".2f",
                 vmin=0,  # 刻度阈值
                 vmax=1,
                 linewidths=1,
                 cmap="RdPu",  # 刻度颜色
                 annot_kws={"size": 8},
                 xticklabels=True,
                 yticklabels=True)  # seaborn.heatmap相关属性
# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
# plt.ylabel(fontsize=15,)
# plt.xlabel(fontsize=15)
plt.title("各储种相关性强弱", fontsize=20)
#plt.xticks(range(60),labels=cols)
plt.show()
